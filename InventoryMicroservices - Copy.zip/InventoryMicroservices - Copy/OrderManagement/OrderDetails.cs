﻿using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Reflection.Emit;


namespace OrderManagement
{
    class MyContext : DbContext
    {
        public DbSet<OrderDetails> Orders { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<OrderDetails>().HasAlternateKey(a => new { a.ProductId,a.UserId });
        }
    }
    public class OrderDetails
    {
        [Key]
        public long OrderId { get; set; }
        public int ProductId { get; set; }
        public int UserId { get; set; }
        public int Quantity  { get; set; }
        public DateTime ExpectedDateOfDelivery { get; set; }
        public bool IsPrePaid { get; set; }
        public float AmountToBePaid { get; set; }
    }
}
