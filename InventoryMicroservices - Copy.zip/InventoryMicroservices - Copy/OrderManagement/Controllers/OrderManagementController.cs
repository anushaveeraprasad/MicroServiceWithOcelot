﻿using Dapper;
using Microsoft.AspNetCore.Mvc;
using Nest;
using System.Text.Json;
using System.Data.SqlClient;
using Newtonsoft.Json;


namespace OrderManagement.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class OrderManagementController : ControllerBase
    {
        private readonly IConfiguration _config;
        public OrderManagementController(IConfiguration config)

        {
            _config = config;
        }
        // GET: api/<OrderManagementController>/1
        [HttpGet("/api/OrderManagement/getOrderDetailsByProductId/{productId}")]
        public async Task<IActionResult> GetOrderDetailsByProductId(int productId)
        {
            try
            {
                var connectionString = new SqlConnection(_config.GetConnectionString("DefaultConnection"));
                var order = await connectionString.QueryAsync<OrderDetails>($"Select * from OrderDetails where ProductId={productId}");
                return Ok(order);
            }
            catch (Exception ex) { await Console.Out.WriteLineAsync(ex.Message); }
            return BadRequest("Something went wrong");
        }
        //[HttpGet("/api/OrderManagement/getOrderDetailsByOrderId/{orderId}")]
        //[HttpGet("{orderId}")]
        //public async Task<IActionResult> GetOrderDetailsByOrderId(long orderId)
        //{
        //    try
        //    {
        //        var connectionString = new SqlConnection(_config.GetConnectionString("DefaultConnection"));
        //        var order = await connectionString.QueryFirstOrDefaultAsync<OrderDetails>($"Select * from OrderDetails where OrderId={orderId}");
        //        return Ok(order);
        //    }
        //    catch (Exception ex) { await Console.Out.WriteLineAsync(ex.Message); }
        //    return BadRequest("Something went wrong");
        //}

        // POST api/<OrderManagementController>/userName
        [HttpPost("{userName}")]
        public async Task<IActionResult> PlaceOrder(OrderDetails objOrder, string userName)
        {
            try
            {
                var connectionString = new SqlConnection(_config.GetConnectionString("DefaultConnection"));
                var IsPrePaid = Convert.ToByte(objOrder.IsPrePaid);
                HttpClient client = new HttpClient();
                client.BaseAddress = new Uri("https://localhost:7080/");
                client.DefaultRequestHeaders.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));

                HttpResponseMessage response = client.GetAsync($"ApiGateway/User/{userName}").Result;
                if (response.IsSuccessStatusCode)
                {
                    var userContent = response.Content.ReadAsStringAsync().Result;
                    Dictionary<string,string> userDictionary= JsonConvert.DeserializeObject<Dictionary<string, string>>(userContent);
                    var requiredUserId = userDictionary.GetValueOrDefault("userId");
                    if (requiredUserId != null)
                    {
                        await connectionString.ExecuteAsync($"insert into OrderDetails values({objOrder.ProductId},{requiredUserId},{objOrder.Quantity},'{DateTime.Today.AddDays(3).ToString("yyyy-MM-dd")}',{IsPrePaid},{objOrder.AmountToBePaid})");
                        return Ok($"Order Placed Successfully for {userName}");
                    }
                    else
                    {
                        return Ok($"User ID for {userName} was not found. Order was not placed. Sorry!! Try again with correct Username");
                    }
                    
                }
                else { return BadRequest("Something went wrong please check request URI"); }

            }
            catch (Exception ex){ //await Console.Out.WriteLineAsync(ex.Message);
                return Ok(ex.Message); }
        }

        // DELETE api/<OrderManagementController>/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> CancelOrder(int id)
        {
            try
            {
                var connectionString = new SqlConnection(_config.GetConnectionString("DefaultConnection"));
                await connectionString.ExecuteAsync($"Delete from OrderDetails where OrderId={id}");
                return Ok("Order Cancelled successfully!");
                
            }
            catch (Exception ex) 
            { 
                await Console.Out.WriteLineAsync(ex.Message);
                return BadRequest("Couldn't cancel the Order. Please check the details and try again");
            }
            
        }
    }
}
