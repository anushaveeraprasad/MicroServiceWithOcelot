﻿using Dapper;
using Microsoft.AspNetCore.Mvc;
using System.Data.SqlClient;
using System.Xml.Linq;

namespace UserManagement.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private readonly IConfiguration _config;
        public UserController(IConfiguration configuration)
        {
            _config = configuration;
        }
        // GET: api/<UserController>
        [HttpGet]
        public async Task<IActionResult> GetAllUsers()
        {
            try
            {
                using var connectionString = new SqlConnection(_config.GetConnectionString("DefaultConnection"));
                var users = await connectionString.QueryAsync<User>("Select * from [User]");
                return Ok(users);
            }
            catch (Exception ex)
            {
                await Console.Out.WriteLineAsync(ex.Message);
                return BadRequest("Something went wrong");
            }
        }

        // GET api/<UserController>/Anu
        [HttpGet("{name}", Order =0)]
        public async Task<IActionResult> GetUserByName(string name)
        {
            try
            {
                using var connectionString = new SqlConnection(_config.GetConnectionString("DefaultConnection"));
                var user = await connectionString.QueryFirstOrDefaultAsync<User>($"Select * from [User] where lower(username)= '{name.ToLower()}'");
                return Ok(user);
            }
            catch (Exception ex)
            {
                await Console.Out.WriteLineAsync(ex.Message);
                return BadRequest("Something went wrong");
            }
        }


        // POST api/<UserController>
        [HttpPost]
        public async Task<IActionResult> AddUser(User objUser)
        {
            try
            {
                using var connectionString = new SqlConnection(_config.GetConnectionString("DefaultConnection"));
                await connectionString.ExecuteAsync($"insert into [User] values('{objUser.UserName}','{objUser.Address}',{objUser.MobileNumber})");
                return Ok("User Added successfully");
            }
            catch (Exception ex)
            {
                await Console.Out.WriteLineAsync(ex.Message);
                return BadRequest("Something went wrong");
                
            }
        }

        // PUT api/<UserController>
        [HttpPut()]
        public async Task<IActionResult> UpdateAddressOfUser(User objUser)
        {
            try
            {
                using var connectionString = new SqlConnection(_config.GetConnectionString("DefaultConnection"));
                await connectionString.ExecuteAsync($"Update [User] set Address='{objUser.Address}' where userId={objUser.UserId}");
                return Ok($"Address updated successfully for {objUser.UserName}");
            }
            catch (Exception ex)
            {
                await Console.Out.WriteLineAsync(ex.Message);
                return BadRequest("Something Went Wrong");

            }
        }

        // DELETE api/<UserController>/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteUserById(int id)
        {
            try
            {
                using var connectionString = new SqlConnection(_config.GetConnectionString("DefaultConnection"));
                await connectionString.ExecuteAsync($"Delete from [User] where userId={id}");
                return Ok($" User bearing userID {id} was deleted successfully");

                
            }
            catch (Exception ex)
            {
                await Console.Out.WriteLineAsync(ex.Message);
                return BadRequest("Something went wrong");

            }

        }
    }
}
