﻿using System.ComponentModel.DataAnnotations;

namespace UserManagement
{
    public class User
    {
        [Key]
        public int UserId { get; set; }
        [Required]
        public string UserName { get; set; }
        [Required]
        public string Address { get; set; }
        [Required]
        public long MobileNumber { get; set; }
    }
}
