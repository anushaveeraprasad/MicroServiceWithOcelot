﻿using System.ComponentModel.DataAnnotations;

namespace ProductManagement
{
    public class Product
    {
        [Key]
        public int ProductId { get; set; }
        [Required]
        public string ProductName { get; set; }
        [Required]
        public float Price { get; set; }
        public string Description { get; set; }
    }
}
