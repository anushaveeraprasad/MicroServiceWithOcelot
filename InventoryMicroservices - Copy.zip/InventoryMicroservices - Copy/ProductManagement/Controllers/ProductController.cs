﻿using Microsoft.AspNetCore.Mvc;
using Dapper;
using System.Data.SqlClient;


namespace ProductManagement.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductController : ControllerBase
    {
        private readonly IConfiguration _config;
        public ProductController(IConfiguration configuration)
        {
            _config = configuration;
        }
        // GET: api/<ProductController>
        [HttpGet]
        public async Task<IActionResult> GetAllProducts()
        {
            try
            {
                var connectionString = new SqlConnection(_config.GetConnectionString("DefaultConnection"));
                var products = await connectionString.QueryAsync<Product>("Select * from Product");
                return Ok(products);
            }
            catch (Exception ex) 
            { 
                await Console.Out.WriteLineAsync(ex.Message);
                return BadRequest("Something went wrong");
            }
            
        }

        // GET api/<ProductController>/5
        [HttpGet("{id}")]
        public async Task<IActionResult> GetProductById(int id)
        {
            try
            {
                var connectionString = new SqlConnection(_config.GetConnectionString("DefaultConnection"));
                var product = await connectionString.QueryFirstOrDefaultAsync<Product>($"Select * from Product where ProductId={id}");
                return Ok(product);
            }
            catch (Exception ex) 
            { await Console.Out.WriteLineAsync(ex.Message);
                return BadRequest("Something Went wrong");
            }
            
        }

        // POST api/<ProductController>
        [HttpPost]
        public async Task<IActionResult> AddProduct(Product objProduct)
        {
            try
            {
                var connectionString = new SqlConnection(_config.GetConnectionString("DefaultConnection"));
                await connectionString.ExecuteAsync($"insert into [Product] values('{objProduct.ProductName}','{objProduct.Description}',{objProduct.Price})");
                return Ok("Product insertion was successful");
            }
            catch (Exception ex) 
            { await Console.Out.WriteLineAsync(ex.Message);
                return BadRequest("Something Went Wrong");
            }
            
        }

        // PUT api/<ProductController>
        [HttpPut()]
        public async Task<IActionResult> UpdateProductPrice(Product objProduct)
        {
            try
            {
                var connectionString = new SqlConnection(_config.GetConnectionString("DefaultConnection"));
                await connectionString.ExecuteAsync($"Update Product set Price= {objProduct.Price} where ProductId={objProduct.ProductId}");
                return Ok("Product Price updated successfully");
            }
            catch (Exception ex) { await Console.Out.WriteLineAsync(ex.Message); return BadRequest("Something went wrong"); }
        }

        // DELETE api/<ProductController>
        [HttpDelete()]
        public async Task<IActionResult> DeleteProductById(Product objProduct)
        {
            try
            {
                var connectionString = new SqlConnection(_config.GetConnectionString("DefaultConnection"));
                await connectionString.ExecuteAsync($"Delete from Product where ProductId={objProduct.ProductId}");
                return Ok("Product Deleted  successfully");
            }
            catch (Exception ex) { await Console.Out.WriteLineAsync(ex.Message); return BadRequest("Smething went wrong"); }
        }
    }
}
